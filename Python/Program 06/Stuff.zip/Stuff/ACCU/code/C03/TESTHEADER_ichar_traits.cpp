//: .\C03:TESTHEADER_ichar_traits.cpp
//: C03:ichar_traits.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Creating your own character traits.
// We'll only change character-by-
// character comparison functions
// Compare the other chars
// ICHAR_TRAITS_H ///:~
#include"ichar_traits.h"
int main() {}
