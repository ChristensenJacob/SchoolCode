//: .\C05:TESTHEADER_Nobloat.cpp
//: C05:Nobloat.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Shares code for storing pointers in a Stack.
// The primary template
// Grow array store
// Full specialization for void*
// Partial specialization for other pointer types
// NOBLOAT_H ///:~
#include"Nobloat.h"
int main() {}
